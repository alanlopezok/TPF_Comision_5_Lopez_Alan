using System;
using System.Collections.Generic;

namespace DeepSpace
{
	public class ArbolGeneral<T>
	{
		
		private T dato;
		private List<ArbolGeneral<T>> hijos = new List<ArbolGeneral<T>>(); 


        public ArbolGeneral(T dato) {
			this.dato = dato;
		}
	
		public T getDatoRaiz() {
			return this.dato;
		}
	
		public List<ArbolGeneral<T>> getHijos() {
			return hijos;
		}
	
		public void agregarHijo(ArbolGeneral<T> hijo) {
			this.getHijos().Add(hijo);
		}
	
		public void eliminarHijo(ArbolGeneral<T> hijo) {
			this.getHijos().Remove(hijo);
		}
	
		public bool esHoja() {
			return this.getHijos().Count == 0;
		}
	
		public int altura() {
			return 0;
		}
	
		
		public int nivel(T dato) {
			return 0;
		}

        public List<T> preorden()
        {
            List<T> descendientesBot = new List<T>();

            descendientesBot.Add(this.dato); // Agrega el dato del nodo actual al recorrido

            foreach (ArbolGeneral<T> hijo in hijos)
            {
                List<T> descendientesHijo = hijo.preorden(); // Obtiene el recorrido preorden de cada hijo
                descendientesBot.AddRange(descendientesHijo); // Agrega los descendientes del hijo al recorrido
            }

            return descendientesBot;
        }

    }
}