﻿
using SharpDX;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace DeepSpace
{

    class Estrategia
    {
        public String Consulta1(ArbolGeneral<Planeta> arbol)
        {
            List<Planeta> caminoBot = new List<Planeta>();

            bool BuscarCamino(ArbolGeneral<Planeta> arbolBusqueda, List<Planeta> caminoPlanetas)
            {
                if (arbolBusqueda != null)
                {
                    caminoPlanetas.Add(arbolBusqueda.getDatoRaiz());

                    if (arbolBusqueda.getDatoRaiz().EsPlanetaDeLaIA()) // si el bot esta en el planeta raiz
                    {
                        return true;
                    }
                }

                foreach (ArbolGeneral<Planeta> arbolHijo in arbolBusqueda.getHijos()) //recursivamente itera y recorre el camino hasta dar con el bot 
                {
                    if (BuscarCamino((ArbolGeneral<Planeta>)arbolHijo, caminoPlanetas)) //si encuentra el bot retorna true
                    {
                        return true;
                    }
                }

                caminoPlanetas.RemoveAt(caminoPlanetas.Count - 1);

                return false;
            }

            BuscarCamino(arbol, caminoBot);

            return $"CONSULTA 1:Distancia entre Planeta Central y ubicacion del bot: {caminoBot.Count - 1} planetas ";
        }//distancia del camino que existe entre el planeta del Bot y la raíz. recursivo




        public string Consulta2(ArbolGeneral<Planeta> arbol)
        {
            List<Planeta> descendientesBot = new List<Planeta>(); //almacenamos los descendientes del bot 

            void BuscarDescendientesBot(ArbolGeneral<Planeta> arbolBusqueda)
            {
                if (arbolBusqueda != null)
                {
                    if (arbolBusqueda.getDatoRaiz().EsPlanetaDeLaIA()) //verificamos si la raiz es el bot 
                    {
                        descendientesBot = arbolBusqueda.preorden(); // Obtiene todos los descendientes en preorden
                    }
                    else
                    {
                        foreach (ArbolGeneral<Planeta> hijo in arbolBusqueda.getHijos()) //recursivamente busca al bot
                        {
                            BuscarDescendientesBot(hijo);
                        }
                    }
                }
            }

            BuscarDescendientesBot(arbol);

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("CONSULTA 2: Descendientes del Bot: "); // creamos la consulta y el formato como queremos mostrarlo
            foreach (Planeta planeta in descendientesBot)
            {
                stringBuilder.Append($"{planeta.Poblacion()} ");
            }
            return stringBuilder.ToString(); //lo retornamos como string 
        }//realiza un recorrido PREORDEN retornando un string donde imprime primero raiz(bot)
                                                                //y descendientes(izquierdos primero y luego derechos)



        public String Consulta3(ArbolGeneral<Planeta> arbol)
        {
            if (arbol == null) //verificamos que el arbol no este vacio
            {
                return "No hay planetas";
            }

            Cola<ArbolGeneral<Planeta>> colaAux = new Cola<ArbolGeneral<Planeta>>(); // creamos una cola para realizar un recorrido por niveles 
            colaAux.encolar(arbol);
            colaAux.encolar(null); // Inicia encolando el nodo raíz (arbol) en la cola y coloca un marcador nulo (null) para distinguir niveles.

            int poblacionTotal = 0;
            int poblacionNivel = 0;
            int planetasPorNivel = 0;
            int niveles = 1;
            string texto = "";

            while (!colaAux.esVacia()) //Mientras la cola no esté vacía, se ejecuta 
            {
                ArbolGeneral<Planeta> arbolAux = colaAux.desencolar();
                if (arbolAux != null)//Si no es nulo, calcula la población total acumulando la población de cada planeta 
                {
                    poblacionTotal += arbolAux.getDatoRaiz().Poblacion();
                    poblacionNivel += arbolAux.getDatoRaiz().Poblacion();
                    planetasPorNivel++;
                    if (arbolAux.getHijos().Count > 0) //Si tiene hijos, los encola para ser procesados en el siguiente nivel.
                    {
                        foreach (ArbolGeneral<Planeta> arbolHijo in arbolAux.getHijos())
                        {
                            colaAux.encolar(arbolHijo);
                        }
                    }
                }
                else //Si encuentra un marcador nulo, se completo el nivel 
                {
                    texto += $"El promedio en el {niveles} es {(float)poblacionNivel / planetasPorNivel}\n"; //Calcula el promedio de población para el nivel actual 
                    poblacionNivel = 0;
                    planetasPorNivel = 0; //Reinicia las variables para el siguiente nivel
                    niveles++;
                    if (!colaAux.esVacia())
                    {
                        colaAux.encolar(null); //avanza al siguiente nivel
                    }
                }

            }

            return $"CONSULTA 3: La poblacion total es de {poblacionTotal}\n{texto}";// Retorna la población total del sistema de planetas y promedios de población por nivel.
        }//población total y promedio por cada nivel del árbol. BUSQUEDA POR NIVELES




        public Movimiento CalcularMovimiento(ArbolGeneral<Planeta> arbol)
        {

            // Buscar nodo del usuario
            List<Planeta> caminoUser = new List<Planeta>(); 


            // Buscar nodo del bot
            List<Planeta> caminoBot = new List<Planeta>();


            bool BuscarCamino(ArbolGeneral<Planeta> arbolBusqueda, List<Planeta> caminoPlanetas, string player) //función recursiva para encontrar los nodos del usuario y del bot
            {
                if (arbolBusqueda != null)  
                {
                    caminoPlanetas.Add(arbolBusqueda.getDatoRaiz()); 

                    if (arbolBusqueda.getDatoRaiz().EsPlanetaDeLaIA() && player == "bot")  //la busqueda se detiene cuando se encuentra al bot o cuando se encuenta al jugador
                    {
                        return true;
                    }
                    if (arbolBusqueda.getDatoRaiz().EsPlanetaDelJugador() && player == "user")
                    {
                        return true;
                    }
                }


                foreach (ArbolGeneral<Planeta> arbolHijo in arbolBusqueda.getHijos()) 
                {
                    if (BuscarCamino((ArbolGeneral<Planeta>)arbolHijo, caminoPlanetas, player))
                    {
                        return true;
                    }
                }

                caminoPlanetas.RemoveAt(caminoPlanetas.Count - 1);

                return false;
            }

            BuscarCamino(arbol, caminoBot, "bot");
            BuscarCamino(arbol, caminoUser, "user");

            // Aplicamos una busqueda que se corte cuando encontramos ambos nodos

            Planeta planetaCercanoBot = null;
            Planeta planetaDestino = null;

            foreach (Planeta planeta in caminoUser) //buscamos los planetas especificos entre el bot y el usuario
            {
                if (planeta.EsPlanetaDeLaIA())
                {
                    planetaCercanoBot = planeta;
                }
                if (planetaCercanoBot != null && planetaDestino == null && !planeta.EsPlanetaDeLaIA())
                {
                    planetaDestino = planeta;
                }
            }

            if (planetaCercanoBot == null) // por si no se encontró ningún planeta que pertenezca al bot se busca el ultimo camino conocido 
            {
                planetaCercanoBot = caminoBot[caminoBot.Count - 1];
                planetaDestino = caminoBot[caminoBot.Count - 2];
            }

            if (planetaCercanoBot.Poblacion() < planetaDestino.Poblacion() + 5)  // aca se identifica el camino al user con el planeta mas grande en poblacion y la diferencia que debe tener
                                                                                    //+ de 5 de la poblacion que va a enviar 
            {

                List<Planeta> caminoHumanoBot = new List<Planeta>(caminoUser);
                caminoHumanoBot.Reverse(); //invierte la lista del camino 
                caminoHumanoBot.Remove(caminoHumanoBot[caminoHumanoBot.Count - 1]); //elimina el ultimo elemento 
                caminoHumanoBot.AddRange(caminoBot); //agrega los elementos de caminobot al final de caminoHumano bot 

                void AgregarNodosBots(ArbolGeneral<Planeta> estado, List<Planeta> lista) //busca los nodos planetas del bot y los agrega a la lista como argumento de forma recursiva
                {                                                                           //explora cada rama

                    if (estado.getDatoRaiz() != null && estado.getDatoRaiz().EsPlanetaDeLaIA() && !lista.Contains(estado.getDatoRaiz()))
                    {
                        lista.Add(estado.getDatoRaiz());
                    }

                    foreach (ArbolGeneral<Planeta> arbolHijo in estado.getHijos())
                    {
                        AgregarNodosBots(arbolHijo, lista);
                    }
                }

                AgregarNodosBots(arbol, caminoHumanoBot); //busca los planetas del bot y los agrega

                Planeta planetaBotMaxPoblacion = null;
                int indexCamino = -1;

                for (int i = 0; i < caminoHumanoBot.Count; i++) //busca la población más alta entre los controlados por bot en caminoHumanoBot y lo asigna a planetaBotMaxPoblacion
                                                                // actualiza indexCamino con la posición de ese planeta en la lista
                {
                    if (caminoHumanoBot[i].EsPlanetaDeLaIA() && planetaBotMaxPoblacion == null)
                    {
                        planetaBotMaxPoblacion = caminoHumanoBot[i];
                        indexCamino = i;
                    }
                    if (caminoHumanoBot[i].EsPlanetaDeLaIA() && planetaBotMaxPoblacion != null && planetaBotMaxPoblacion.Poblacion() < caminoHumanoBot[i].Poblacion())
                    {
                        planetaBotMaxPoblacion = caminoHumanoBot[i];
                        indexCamino = i;
                    }
                }

                Planeta destinoPoblacion = caminoHumanoBot[indexCamino - 1];

                return new Movimiento(planetaBotMaxPoblacion, destinoPoblacion); //realiza el movimiento

            }

            return new Movimiento(planetaCercanoBot, planetaDestino); //realiza el movimiento A
        } //RECURSIVO
    }
}
